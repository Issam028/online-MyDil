<?php
session_start(); // Démarre la session

// Récupère les données POST
$data = json_decode(file_get_contents('php://input'), true);
$username = isset($data['username']) ? $data['username'] : null;
$hashedPassword = isset($data['password']) ? $data['password'] : null;

// Débogage des données reçues
error_log("Données reçues : " . print_r($data, true));
error_log("username " . print_r($username, true));
if ($username && $hashedPassword) {
    try {
        $bdd = new PDO('mysql:host=localhost;dbname=proj_physique;charset=utf8', 'root', 'root');
        $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Rechercher dans chaque table successivement
        $tables = ['eleve', 'enseignant', 'admin'];
        $user = null;
        $role = null;

        foreach ($tables as $table) {
            $stmt = $bdd->prepare("SELECT * FROM $table WHERE identifiant = ?");
            $stmt->execute([$username]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($user) {
                $role = $table;
                break;
            }
        }

        if ($user && $user['mot_de_passe'] === $hashedPassword) {
            $_SESSION['user_authenticated'] = true;
            $_SESSION['user_authenticated_time'] = time();
    
            // Vérifier si l'ID de l'utilisateur est défini avant de l'assigner
            $userId = isset($user['id_utilisateur']) ? $user['id_utilisateur'] : null;
            $_SESSION['user_id'] = $userId;

            $_SESSION['user_role'] = $role;

            // Définir l'URL de redirection en fonction du rôle de l'utilisateur
            switch ($role) {
                case 'eleve':
                    $redirectUrl = 'page_eleve.php';
                    break;
                case 'enseignant':
                    $redirectUrl = 'page_prof.html';
                    break;
                case 'admin':
                    $redirectUrl = 'page_gestionBdd.html';
                    break;
                default:
                    $redirectUrl = 'index.html';
                    break;
            }

            echo json_encode(['success' => true, 'redirect' => $redirectUrl]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Nom d\'utilisateur ou mot de passe incorrect']);
        }
    } catch (PDOException $e) {
        error_log("Erreur PDO : " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Erreur de connexion à la base de données']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Données manquantes']);
}

// Vérifier si la session a expiré après 5 minutes d'inactivité
if (isset($_SESSION['user_authenticated_time']) && $_SESSION['user_authenticated_time'] + 300 <= time()) {
    session_unset();
    session_destroy();
}
?>
