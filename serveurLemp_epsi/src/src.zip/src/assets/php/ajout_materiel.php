<?php
$servername = "10.0.0.1";
$username = "root";
$password = "root";
$dbname = "proj_physique";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname;charset=utf8", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $nom_materiel = $_POST['nom_materiel'];
        $quantite = $_POST['quantite'];
        $reserver = $_POST['reserver'];
        $indisponible = $_POST['indisponible'];

        $stmt = $conn->prepare("INSERT INTO materiel (nom_materiel, quantite, reserver, indisponible) VALUES (?, ?, ?, ?)");
        $stmt->execute([$nom_materiel, $quantite, $reserver, $indisponible]);

        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
    }
} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
$conn = null;
?>
