<?php
// fetch_activite.php

// Connectez-vous � votre base de donn�es
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "proj_physique";

try {
    // Connexion � la base de donn�es
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

$sql = "SELECT 
            a.id_activite,
            a.titre,
            a.description,
            e.nom AS nom_enseignant,
            e.prenom AS prenom_enseignant,
            c.nom_classe
        FROM 
            activite a
        JOIN 
            enseignant e ON a.id_professeur = e.id_enseignant
        JOIN 
            lien_classe_activite lca ON a.id_activite = lca.id_activite
        JOIN 
            classe c ON lca.id_classe = c.id_classe";

try {
    $stmt = $conn->prepare($sql);
    $stmt->execute();

    $activities = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $activity = [
            'title' => $row['titre'],
            'description' => $row['description'],
            'professor_name' => $row['nom_enseignant'] . ' ' . $row['prenom_enseignant'],
            'class_name' => $row['nom_classe'],
            'documents' => [],
            'videos' => []
        ];

        $activity_id = $row['id_activite'];

        // Fetch documents
        try {
            $doc_sql = "SELECT file_path FROM documents WHERE id_activite = :id_activite";
            $doc_stmt = $conn->prepare($doc_sql);
            $doc_stmt->bindParam(':id_activite', $activity_id);
            $doc_stmt->execute();

            while ($doc_row = $doc_stmt->fetch(PDO::FETCH_ASSOC)) {
                $activity['documents'][] = ['file_path' => $doc_row['file_path']];
            }
        } catch (PDOException $e) {
            // Gestion des erreurs pour les documents
            $activity['documents'][] = ['file_path' => 'Aucun document trouv�'];
        }

        // Fetch videos
        try {
            $video_sql = "SELECT file_path FROM videos WHERE id_activite = :id_activite";
            $video_stmt = $conn->prepare($video_sql);
            $video_stmt->bindParam(':id_activite', $activity_id);
            $video_stmt->execute();

            while ($video_row = $video_stmt->fetch(PDO::FETCH_ASSOC)) {
                $activity['videos'][] = ['file_path' => $video_row['file_path']];
            }
        } catch (PDOException $e) {
            // Gestion des erreurs pour les vid�os
            $activity['videos'][] = ['file_path' => 'Aucune vid�o trouv�e'];
        }

        $activities[] = $activity;
    }

    header('Content-Type: application/json');
    echo json_encode($activities);
} catch (PDOException $e) {
    die("Erreur lors de l'ex�cution de la requ�te SQL: " . $e->getMessage());
}

$conn = null;
?>
